import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String myJavaCore;
        final int NUM = 12;
        String word = "New World";
        myJavaCore = NUM + word;
        System.out.println(myJavaCore + " " + NUM + " " + word);
        if (NUM < 0) System.out.println("Вы сохранили отрицательное число");
        else if (NUM > 0) System.out.println("Вы сохранили положительное число");
        else System.out.println("Вы сохранили ноль");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите ваше имя: ");
        String username = scanner.nextLine();
        System.out.println("Привет, " + username + "!");
    }
}